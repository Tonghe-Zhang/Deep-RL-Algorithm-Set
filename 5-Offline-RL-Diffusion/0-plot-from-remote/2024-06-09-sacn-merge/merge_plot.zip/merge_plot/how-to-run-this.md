first make the directory look like this

![alt text](./how-to-run-this.assets/image-1.png)

then 

```cmd
python run merge_plot.py
```

