

> python run_example/run_edac.py --num-critics 10 --eta 1.0

> python run_example/plotter.py --algos edac --task halfcheetah-medium-v2 --output-path ./halfcheetah-medium-v2-edac.png
